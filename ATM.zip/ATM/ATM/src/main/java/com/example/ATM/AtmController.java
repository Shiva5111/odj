package com.example.ATM;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
;

@Controller
public class AtmController {
	
	@Autowired
	private AtmRepository atmrepo;
	
	@GetMapping("/withdraw")
	public String withdrawPage() {
		return "withdraw";
	}
	@PostMapping("/withdraw")
	public String withdraw(@RequestParam String name, @RequestParam Integer amount, Model model) {
		Optional<User> u=atmrepo.findByName(name);
		if(u.isPresent()) {
			User userpresent=u.get();
			if(userpresent.getBalance() >= amount && amount>0 && name.equals(userpresent.getName())) {
				Integer remainbalance=userpresent.getBalance()- amount;
				userpresent.setBalance(remainbalance);
				atmrepo.save(userpresent);
				model.addAttribute("Message",
                "Withdraw successful. Remaining balance: " + userpresent.getBalance());
        		return "withdraw";
			}else
				model.addAttribute("errorMessage",
                    "Insufficient balance. Current balance: " + userpresent.getBalance());
            	return "withdraw";
		}else {
			 model.addAttribute("errorMessage", "User not found");
			 return "withdraw";
		}
	}

}
