package com.example.inventory_service.Service;

import org.springframework.stereotype.Service;

import com.example.inventory_service.Repository.InventoryRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class InventoryService {

    private final InventoryRepository inventoryrepository;

    public boolean isInStock(String skucode) {
        return inventoryrepository.findByskucode(skucode).isPresent();
       
    }

    public Integer available(String skucode) {
        Integer qty = inventoryrepository.getquantityByskucode(skucode);
        return (qty != null) ? qty : 0;
        
    }

}
