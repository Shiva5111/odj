package com.example.inventory_service.Controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.inventory_service.Service.InventoryService;

import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseStatus;




@RestController
@RequiredArgsConstructor
@RequestMapping("/api/inventory")
public class InventoryController {
     
    private final InventoryService inventoryservice;

    @GetMapping("/{skucode}")
    @ResponseStatus(HttpStatus.OK)
    public boolean isInStock(@PathVariable String skucode){
        return inventoryservice.isInStock(skucode);
    }
    
    @GetMapping("/quantity/{skucode}")
    @ResponseStatus(HttpStatus.OK)
    public Integer available(@PathVariable String skucode) {
        return inventoryservice.available(skucode);
    }
    
    
}
