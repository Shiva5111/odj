package com.example.order_service.Feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient("inventory-service")
public interface FeignInterface {

    @GetMapping("/api/inventory/{skucode}")
    public boolean isInStock(@PathVariable("skucode") String skucode);

    @GetMapping("/api/inventory/quantity/{skucode}")
    public Integer available(@PathVariable String skucode);
}