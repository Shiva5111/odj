package com.example.order_service.Feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.order_service.Model.AddCart;

@FeignClient(name="AddToCart")
public interface addcartfegninterface {

    @GetMapping("/cart/getcartproducts")
    public List<AddCart> GetAllproductsincart();

    @GetMapping("/cart/totalprice/{id}")
    public float gettotalprice(@PathVariable("id") int id);
}
