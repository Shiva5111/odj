package com.example.order_service.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.order_service.Feign.addcartfegninterface;
import com.example.order_service.Model.AddCart;
import com.example.order_service.Model.Order;
import com.example.order_service.Repository.OrderRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class OrderService {

    @Autowired
    private final OrderRepository orderrepository;

    @Autowired
    private final addcartfegninterface feigninterface;

    public Order placedorder(Order order) {
        return orderrepository.save(order);    
    }

    public List<AddCart> buynow() {
        return feigninterface.GetAllproductsincart();
    }

    public float getcartprice(int id) {
        return feigninterface.gettotalprice(id);
        
    }

}
