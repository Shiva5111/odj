package com.example.order_service.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.order_service.Feign.FeignInterface;
import com.example.order_service.Model.AddCart;
import com.example.order_service.Model.Order;
import com.example.order_service.Service.OrderService;

import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;




@RestController
@RequiredArgsConstructor
@RequestMapping("/api/order")
public class OrderController {

    private final OrderService orderservice;

    @Autowired
    private FeignInterface fi;

    @PostMapping("/placeorder")
    public String placeorder(@RequestBody Order order) {
        List<String> productsnotavailable = new ArrayList<>();
        List<Integer> productquantitynotavailable = new ArrayList<>();
        int a=order.getItems().size();
        int count=0;
        for(int i=0;i<a;i++){
        String skuCode = order.getItems().get(i).getSkucode();
        boolean inStock = fi.isInStock(skuCode);
        int quantity=order.getItems().get(i).getQuantity();
        Integer available=fi.available(skuCode);
        if(inStock && quantity<=available){
        count++;
        }else{
            productsnotavailable.add(skuCode);
            productquantitynotavailable.add(available);
        }
    }
        if (count==a) {
            orderservice.placedorder(order);
            return "Order placed successfully";
        } else{
            return  " these products are not available or out of stock " + 
            productsnotavailable + productquantitynotavailable;
        }
    }
    @GetMapping("/buy")
    public List<AddCart> buynow() {
        return orderservice.buynow();
    }
    
    @GetMapping("/cartprice/{cartid}")
    public float getcartprice(@PathVariable int cartid) {
        return orderservice.getcartprice(cartid);
    }
    
}
