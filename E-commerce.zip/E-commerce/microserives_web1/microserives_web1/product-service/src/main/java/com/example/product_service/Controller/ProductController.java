package com.example.product_service.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.product_service.dto.dtotoentity;
import com.example.product_service.dto.entitytodto;
import com.example.product_service.model.Product;
import com.example.product_service.service.ProductService;

import lombok.RequiredArgsConstructor;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;





@RestController
@RequiredArgsConstructor
@RequestMapping("/api/product")
public class ProductController {

    
    private final ProductService productservice;

    @PostMapping("/add")
    @ResponseStatus(HttpStatus.CREATED)
    public void addProduct(@RequestBody Product product) {
        productservice.addProduct(product);
    }
    
    @GetMapping("/all")
    @ResponseStatus(HttpStatus.OK)
    public List<Product> getAllproducts() {
        return productservice.getAllproducts();
    }
    
    @GetMapping("/get/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Optional<entitytodto> getbyid(@PathVariable int id) {
        return productservice.getbyid(id);
    }
    
    @DeleteMapping("/delete/{id}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteByid(@PathVariable int id){
         productservice.deleteByid(id);
    }

    @PutMapping("/update/{id}")
    public Product updateproduct(@PathVariable int id, @RequestBody dtotoentity dtotoentity) {
        return productservice.updateproduct(id, dtotoentity);
    }
}
