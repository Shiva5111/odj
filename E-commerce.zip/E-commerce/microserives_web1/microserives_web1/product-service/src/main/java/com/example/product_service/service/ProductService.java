package com.example.product_service.service;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.example.product_service.dto.dtotoentity;
import com.example.product_service.dto.entitytodto;
import com.example.product_service.model.Product;
import com.example.product_service.repository.ProductRepository;

import lombok.RequiredArgsConstructor;


@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productrepository;
    private final ModelMapper modelMapper;
    public void addProduct(Product product) {
        productrepository.save(product);
    }

    public List<Product> getAllproducts() {
        return productrepository.findAll();

    }

    public Optional<entitytodto> getbyid(int id) {
        return productrepository.findById(id)
        .map(this::getfromdto);
    }
    private entitytodto getfromdto(Product product){
        return modelMapper.map(product, entitytodto.class);
    }
    public String deleteByid(int id) {
        Optional<Product> productpresent=productrepository.findById(id);
        if(productpresent.isPresent()){
            productrepository.deleteById(id);
        }
        return id + "deleted ";
    }

    public Product updateproduct(Integer id, dtotoentity dtotoentity) {
        Optional<Product> productpresent = productrepository.findById(id);
        if(productpresent.isPresent()){
          Product updateproduct=productpresent.get(); 
            modelMapper.map(dtotoentity, updateproduct);
            return productrepository.save(updateproduct);
        }else
        return null;
    }
}
