package com.example.Addtocart.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.example.Addtocart.DTO.AddCartdto;
import com.example.Addtocart.DTO.AddCartdtotoentity;
import com.example.Addtocart.DTO.Selecteditemsdto;
import com.example.Addtocart.DTO.Selecteditemsdtotoentity;
import com.example.Addtocart.Model.AddCart;
import com.example.Addtocart.Model.Selecteditems;
import com.example.Addtocart.Repository.AddCartRepo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AddCartService {

    private final AddCartRepo addcartrepo;
    private final ModelMapper modelMapper;


    public void addTocart(AddCart addcart) {
         addcartrepo.save(addcart);
    }

    public List<AddCartdto> GetAllproductsincart() {
        return addcartrepo.findAll()
        .stream()
        .map(this::carttodto)
        .toList();
    }

    private AddCartdto carttodto(AddCart cart) {
    AddCartdto dto = modelMapper.map(cart, AddCartdto.class);

    // manually map list items
    dto.setSelecteditems(
            cart.getSelecteditems()
                .stream()
                .map(item -> modelMapper.map(item, Selecteditemsdto.class))
                .toList()
    );

    return dto;
}


    public float gettotalprice(int id) {
    Optional<AddCart> optionalCart = addcartrepo.findById(id);
        AddCart cart = optionalCart.get();
        float total = 0;
        if (cart.getSelecteditems() != null) {
            for (Selecteditems item : cart.getSelecteditems()) {
                total += item.getPrice(); 
            }
        }

        return total;
    }

    public Optional<AddCart> updatecart(int id, AddCartdtotoentity addcartdtotoentity) {
        return addcartrepo.findById(id)
        .map(existingcart -> {mapdtotoentity(addcartdtotoentity, existingcart);
        return addcartrepo.save(existingcart);
        });
    }

    private void mapdtotoentity(AddCartdtotoentity addCartdtotoentity, AddCart existingcart) {
    modelMapper.map(addCartdtotoentity, existingcart);

   List<Selecteditems> items = addCartdtotoentity.getSelecteditems()
        .stream()
        .map(itemDto -> {
            Selecteditems item = modelMapper.map(itemDto, Selecteditems.class);
            item.setAddcart(existingcart);
            return item;
        })
       .collect(Collectors.toList());

    }

}
