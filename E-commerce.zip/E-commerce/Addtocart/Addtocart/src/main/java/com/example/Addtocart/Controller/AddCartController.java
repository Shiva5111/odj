package com.example.Addtocart.Controller;

import org.springframework.web.bind.annotation.RestController;

import com.example.Addtocart.DTO.AddCartdto;
import com.example.Addtocart.DTO.AddCartdtotoentity;
import com.example.Addtocart.Model.AddCart;
import com.example.Addtocart.service.AddCartService;

import lombok.RequiredArgsConstructor;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PutMapping;




 

@RestController
@RequiredArgsConstructor
@RequestMapping("/cart")
public class AddCartController {

    private final AddCartService addcartservice;

    @PostMapping("/addtocart")
    @ResponseStatus(HttpStatus.CREATED)
    public void AddTocart(@RequestBody AddCart addcart) {
         addcartservice.addTocart(addcart);
    }
    
    @GetMapping("/getcartproducts")
    @ResponseStatus(HttpStatus.OK)
    public List<AddCartdto> GetAllproductsincart() {
        return addcartservice.GetAllproductsincart();
    }
    
    @GetMapping("/totalprice/{cartid}")
    public float gettotalprice(@PathVariable int cartid) {
        return addcartservice.gettotalprice(cartid);
    }
    
    @PutMapping("update/{id}")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public Optional<AddCart> updatecart(@PathVariable int id, @RequestBody AddCartdtotoentity addCartdtotoentity) {
        return addcartservice.updatecart(id, addCartdtotoentity);
    }
}
