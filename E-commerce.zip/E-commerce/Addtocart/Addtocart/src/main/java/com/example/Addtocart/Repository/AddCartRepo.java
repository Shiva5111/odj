package com.example.Addtocart.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Addtocart.Model.AddCart;

public interface AddCartRepo extends JpaRepository<AddCart, Integer>{

}
