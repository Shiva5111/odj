
package com.example.demo.Repository;
import com.example.demo.Pojo.User;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


public interface UserRepository extends JpaRepository<User, Integer>{

	User findByName(String name);

	Optional<User> findByNameAndPassword(String name, String password);

}
