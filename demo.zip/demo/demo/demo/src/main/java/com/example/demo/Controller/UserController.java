package com.example.demo.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Repository.UserRepository;
import com.example.demo.Pojo.User;

@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserRepository repo;
	
	@GetMapping("/getusers")
	public List<User> getUsers(){
		return repo.findAll();
	}
	@PostMapping("/postuser")
	public User postStudent(@RequestBody User user) {
		 return repo.save(user);
	}
	@DeleteMapping("/deleteuser/{id}")
	public Object deleteUser(@PathVariable Integer id) {
		Optional<User> s=repo.findById(id);
		if(s.isPresent())
			repo.deleteById(id);
		else
			return "not found";
		return s;
	}
	
	@GetMapping("/fetchuser/{name}/{password}")
	public String fetchUser(@PathVariable String name, @PathVariable String password) {
		Optional<User> u=repo.findByNameAndPassword(name, password);
		if(u.isPresent()) {
		return "Welcome to the page";
		}
		else {
			return "user or password is wrong";
		}
	}
}
