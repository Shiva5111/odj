package com.example.members.service;

import com.example.members.dto.Memberbookborroweddto;
import com.example.members.feign.booksinterface;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.example.members.model.Member;
import com.example.members.repository.MembersRepository;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class MemberService {

    private final MembersRepository membersRepository;
    private final ModelMapper modelMapper;
    private final booksinterface booksinterface;

    public List<Member> getAllMembers() {
        return membersRepository.findAll();
    }

    public Member getMemberById(int id) {
       return membersRepository.findById(id).orElse(null);
    }

    public void deleteMemberById(int id) {
       membersRepository.deleteById(id);
    }

    public Member addMember(Member member) {
        return membersRepository.save(member);
    }

    public Member updateMember(int id, Member member) {
        Member memberpresent = membersRepository.findById(id).orElse(null);
        if (memberpresent != null) {  
            modelMapper.map(member, memberpresent);
            return membersRepository.save(memberpresent);
        } else {
            return null;    
        }
    }

    public Memberbookborroweddto borrowingbook(int id, String title) {
        Member memberpresent = membersRepository.findById(id).orElse(null);
        int bookId = booksinterface.getbookidbybookname(title);
        List<Integer> ids = memberpresent.getBookIds();
        ids.add(bookId);
        int copiesavailable=booksinterface.getavailablecopiesbybooknam(title);
        if(memberpresent != null && memberpresent.getTotalbookstaken()<5 && copiesavailable>0) { 
        memberpresent.setBookIds(ids);
        memberpresent.setTotalbookstaken(memberpresent.getTotalbookstaken()+1);
        membersRepository.save(memberpresent);
        return modelMapper.map(memberpresent, Memberbookborroweddto.class);

       }
       return null;
    }

    public Object returnBook(int id, String bookname) {
        Member memberpresent=membersRepository.findById(id).orElse(null);
        if(memberpresent==null){
            return "member not present" + id;
        }
        int returningbookid=booksinterface.getbookidbybookname(bookname);
        if(returningbookid==0){
            return "book not present " + bookname;
        }
        List<Integer> ids=memberpresent.getBookIds();
        if (!ids.contains(returningbookid)){
            return "book with id "+returningbookid+" not borrowed by member with id "+id;
        }
            ids.remove(Integer.valueOf(returningbookid));
            memberpresent.setBookIds(ids);
            memberpresent.setTotalbookstaken(memberpresent.getTotalbookstaken()-1);
            membersRepository.save(memberpresent);
            return modelMapper.map(memberpresent, Memberbookborroweddto.class);
    }

    public Object booksByAuthor(String author) {
       return booksinterface.searchAllByAuthors(author);
    }
}