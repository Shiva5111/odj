package com.example.members.Controller;

import org.springframework.web.bind.annotation.RestController;

import com.example.members.dto.BorrowRequest;
import com.example.members.dto.Memberbookborroweddto;
import com.example.members.dto.returningbook;
import com.example.members.model.Member;
import com.example.members.service.MemberService;
import lombok.RequiredArgsConstructor;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;





@RestController
@RequiredArgsConstructor
@RequestMapping("members")
public class MemberController {

    private final MemberService memberService;

    @GetMapping("/allmembers")
    @ResponseStatus(HttpStatus.OK)
    public List<Member> getMethodName() {
        return memberService.getAllMembers();
    }
    
    @GetMapping("/getById/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Member getMethodName(@PathVariable int id) {
        return memberService.getMemberById(id);
    }
    
    @DeleteMapping("/deleteById/{id}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteMemberById(@PathVariable int id) {
        memberService.deleteMemberById(id);
    }

    @PostMapping("/addmember")
    public Member addMember(@RequestBody Member member) {
        return memberService.addMember(member);
    }
    
    @PutMapping("updatemember/{id}")
    public Member putMethodName(@PathVariable int id, @RequestBody Member member) {
        return memberService.updateMember(id, member);
    }

    @PostMapping("/borrowbook/{id}")
    public Memberbookborroweddto borrowingbook(@PathVariable int id, @RequestBody BorrowRequest title) {
       return memberService.borrowingbook(id, title.getBookname());
    }
    
    @PostMapping("/returnbook/{id}")
    public Object returnBook(@PathVariable int id, @RequestBody returningbook entity) {
        return memberService.returnBook(id, entity.getBookname());
    }
    

    @PostMapping("/booksByAuthor/{author}")
    public Object booksByAuthor(@PathVariable String author) {
        return memberService.booksByAuthor(author);
    }
    
}
