package com.example.members.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "library-books")
public interface booksinterface {

    @GetMapping("/books/getidbyname/{title}")
    int getbookidbybookname(@PathVariable("title") String bookname);

    @GetMapping("/books/getavailablecopiesbybooknam/{title}")
    public int getavailablecopiesbybooknam(@PathVariable("title") String title);

    @GetMapping("/books/getbookbyname/{title}")
    public String findBytitle(@PathVariable("title") String bookname);

    @GetMapping("/books/searchbyauthor/{author}")
    public Object searchAllByAuthors(@PathVariable("author") String author);
}
