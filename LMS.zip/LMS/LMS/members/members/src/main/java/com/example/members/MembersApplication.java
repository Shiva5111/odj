package com.example.members;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import com.example.members.model.Member;

@SpringBootApplication
@EnableFeignClients
@EnableDiscoveryClient
public class MembersApplication {

	public static void main(String[] args) {
		SpringApplication.run(MembersApplication.class, args);
		System.out.println("Members Service is running...");
	}
	
@Bean
public ModelMapper modelMapper() {
    ModelMapper mapper = new ModelMapper();

    mapper.typeMap(Member.class, Member.class).addMappings(m -> {
        m.skip(Member::setId);
    });

    return mapper;
}

}
