package com.example.library_books.Controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.library_books.DTO.Bookresponsedto;
import com.example.library_books.DTO.Bookupdatedto;
import com.example.library_books.Model.Book;
import com.example.library_books.Service.BookService;
import lombok.RequiredArgsConstructor;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;




@RestController
@RequiredArgsConstructor
@RequestMapping("/books")
public class BookController {

    private final BookService bookService;

    @GetMapping("/allbooks")
    @ResponseStatus(HttpStatus.OK)
    public List<Book> getAllBooks() {
        return bookService.getAllbooks();
    }

    @GetMapping("/getbook/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Optional<Book> getBookById(@PathVariable int id) {
        return bookService.getBookById(id);
    }

    @DeleteMapping("/deletebook/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT) 
    public void deleteBookById(@PathVariable int id) {
        bookService.deleteBookById(id);
    }

    @PostMapping("/addbook")
    @ResponseStatus(HttpStatus.CREATED)
    public Bookresponsedto addBook(@RequestBody Book book){
        return bookService.addBook(book);
    }

    @PutMapping("/updatebook/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Book updateBook(@PathVariable int id,@RequestBody Bookupdatedto book) {
        return bookService.updateBook(id, book);
    }

   @GetMapping("/getidbyname/{title}")
   public int getbookidbybookname(@PathVariable String title) {
       return bookService.getbookidbybookname(title);
   }
   
   @GetMapping("/getavailablecopiesbybooknam/{title}")
   public int getavailablecopiesbybooknam(@PathVariable String title) {
       return bookService.getavailablecopiesbybooknam(title);
   }
   
    @GetMapping("/getbookbyname/{title}")
    public String findBytitle(@PathVariable("title") String bookname){
        return bookService.findBytitle(bookname);
    }

    @GetMapping("/searchbyauthor/{author}")
    public Object searchAllByAuthors(@PathVariable String author) {
       return bookService.searchAllByAuthors(author);
    } 


    @GetMapping("/sorting/{field}")
    public Object sortByfield(@PathVariable String field) {
        return bookService.sortbyField(field);
    }
    
    @GetMapping("/pagination/{offset}/{pageSize}")
    public Object pagination(@PathVariable int offset, @PathVariable int pageSize) {
        return bookService.pagination(offset, pageSize);
    }

    @GetMapping("/pns/{offset}/{pageSize}/{field}")
    public Object pns(@PathVariable int offset, @PathVariable int pageSize, @PathVariable String field) {
        return bookService.pns(offset, pageSize, field);
    }
    
}
