package com.example.library_books.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.hibernate.query.Page;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.library_books.DTO.Bookresponsedto;
import com.example.library_books.DTO.Bookupdatedto;
import com.example.library_books.DTO.SearchByAuthor;
import com.example.library_books.Exceptions.BookNotFoundException;
import com.example.library_books.Model.Book;
import com.example.library_books.Repository.Bookrepository;

import lombok.RequiredArgsConstructor;


@Service
@RequiredArgsConstructor
public class BookService {

    private final Bookrepository bookRepository;
    private final ModelMapper modelMapper;

    public List<Book> getAllbooks() {
        return bookRepository.findAll();
    }

    public Optional<Book> getBookById(int id) {
        return bookRepository.findById(id);
    }

    public void deleteBookById(int id) {
        bookRepository.deleteById(id);
    }

    public Bookresponsedto addBook(Book book) {
        Book savedBook = bookRepository.save(book);
        return modelMapper.map(savedBook, Bookresponsedto.class);
    }

    public Book updateBook(int id, Bookupdatedto book) {
        Optional<Book> bookpresent = bookRepository.findById(id);
        if(bookpresent.isPresent()){
            Book existingbook = bookpresent.get();
            modelMapper.map(book, existingbook);
            return bookRepository.save(existingbook);
        }
        else{
            return null;
        }
    }

  public int getbookidbybookname(String title) {
    Book book = bookRepository.findBytitle(title);
    if (book == null) {
        throw new BookNotFoundException("Book not found: " + title);
    }   
    return book.getId();
}


    public int getavailablecopiesbybooknam(String title) {
        int copiesavailable=0;
        return  copiesavailable = bookRepository.findBytitle(title).getAvailableCopies();
    }

    public String findBytitle(String bookname) {
        Book book = bookRepository.findBytitle(bookname);
        if (book != null) {
            return book.getTitle();
        } else {
            return null;
        }
    }

    public Object searchAllByAuthors(String author) {
        List<Book> books = bookRepository.searchByAuthor(author);
        if (books == null || books.isEmpty()) {
            return List.of("message", "No books found for author: " + author);
        }
        return books.stream()
                .map(Book::getTitle)
                .toList();
    }

    public Object sortbyField(String field) {
       return bookRepository.findAll(Sort.by(Sort.Direction.DESC, field));
    }

    public Object pagination(int offset, int pageSize) {
        return bookRepository.findAll(PageRequest.of(offset, pageSize));
    }

    public Object pns(int offset, int pageSize, String field) {
        return bookRepository.findAll(PageRequest.of(offset, pageSize).withSort(Sort.Direction.ASC, field));
    }
}

