package com.example.library_books.payload;

import java.time.Instant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class APIResponse<T> {
    private String Status;
    private String message;
    private Instant timestamp;
    private T data;



    public static <T> APIResponse<T> success(String message, T data) {
        return new APIResponse<T>("success", message, Instant.now(), data);
    }

    public static <T> APIResponse<T> failure(String message, T data) {
        return new APIResponse<T>("failure", message, Instant.now(), data);
    }
}
