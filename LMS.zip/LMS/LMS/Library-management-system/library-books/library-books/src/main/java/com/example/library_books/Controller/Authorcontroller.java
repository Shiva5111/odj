package com.example.library_books.Controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.library_books.DTO.authorsupdatedto;
import com.example.library_books.Model.Author;
import com.example.library_books.Service.AuthorService;

import lombok.RequiredArgsConstructor;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;



@RestController
@RequiredArgsConstructor
@RequestMapping("/authors")
public class Authorcontroller {

    private final AuthorService authorservice;

    @PutMapping("/updateauthors/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Author updateauthors(@PathVariable int id, @RequestBody authorsupdatedto author) {
        return authorservice.updateauthors(id, author);
    }

    @GetMapping("/getall")
    @ResponseStatus(HttpStatus.OK)
    public List<Author> getMethodName() {
        return authorservice.getAllAuthors();
    }
    
    @GetMapping("/getById/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Author getAuthorById(@PathVariable int id) {
        return authorservice.getAuthorById(id);
    }

    @DeleteMapping("/delete/{id}")  
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteAuthorById(@PathVariable int id) {    
        authorservice.deleteAuthorById(id);
    }

    @PostMapping("/addauthor")
    public Author addAuthoe(@RequestBody Author author) {
        return authorservice.addAuthor(author);
    }
    
}