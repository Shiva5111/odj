package com.example.library_books.Service;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import com.example.library_books.DTO.authorsupdatedto;
import com.example.library_books.Model.Author;
import com.example.library_books.Repository.AuthorRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuthorService {

    private final AuthorRepository authorRepository;
    private final ModelMapper modelMapper;


    public Author updateauthors(int id, authorsupdatedto author) {
        Optional<Author> authorpresent = authorRepository.findById(id);
        if(authorpresent.isPresent()){
            Author existingauthor = authorpresent.get();
            modelMapper.map(author, existingauthor);
            return authorRepository.save(existingauthor);
        }
        else{
            return null;
        }
    }


    public List<Author> getAllAuthors() {
        return authorRepository.findAll();
    }


    public Author getAuthorById(int id) {
       return authorRepository.findById(id).orElse(null);
    }


    public void deleteAuthorById(int id) {
        authorRepository.deleteById(id);
    }


    public Author addAuthor(Author author) {
       return authorRepository.save(author);
    }
}
