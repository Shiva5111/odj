package com.example.library_books.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Bookupdatedto {

    private Integer totalCopies;
    private Integer availableCopies;

}
