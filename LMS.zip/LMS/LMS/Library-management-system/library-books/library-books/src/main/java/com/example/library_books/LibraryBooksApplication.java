package com.example.library_books;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;

import com.example.library_books.Model.Book;

@SpringBootApplication
@EnableFeignClients
@EnableDiscoveryClient
public class LibraryBooksApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryBooksApplication.class, args);
		System.out.println("Library Books Service is running...");
	}

	@Bean
	public ModelMapper modelmapper(){
    ModelMapper mapper = new ModelMapper();

    mapper.getConfiguration()
          .setSkipNullEnabled(true); // ✅ prevents overwriting with nulls

    mapper.typeMap(Book.class, Book.class)
          .addMappings(m -> m.skip(Book::setId)); // ✅ prevents ID overwrite

    return mapper;

	}
}
