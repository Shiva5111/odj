package com.example.library_books.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.library_books.Model.Book;

import feign.Param;


@Repository
public interface Bookrepository extends JpaRepository<Book, Integer> {

    Book findBytitle(String title);

@Query("SELECT b FROM Book b JOIN b.authors a WHERE LOWER(a.name) LIKE LOWER(CONCAT('%', :author, '%'))")
List<Book> searchByAuthor(@Param("author") String author);


}
