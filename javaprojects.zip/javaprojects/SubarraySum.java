package javaprojects;


import java.util.*;



public class SubarraySum{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int tc = sc.nextInt();
        
        for (int i = 0; i < tc; i++){
            int size = sc.nextInt();
            List<Integer> a=new ArrayList<>();
            for (int y = 0; y < size; y++) {
                a.add(sc.nextInt());
            }
            subarrays(a);
        }
    }
   
    
    public static void subarrays(List<Integer> a){
        int sum=0;
        int n=a.size();
        for (int y = 0; y < a.size(); y++) {
             for (int i = y; i < n; i++) {
                 List<Integer> ma=new ArrayList<>();
                 for(int k=y;k<=i;k++){
                ma.add(a.get(k));
                Collections.sort(ma);
                }
                 sum=sum+(ma.get(ma.size()-1) - ma.get(0)); 
                 
            }
        }  
        System.out.println(sum);   
    }
}