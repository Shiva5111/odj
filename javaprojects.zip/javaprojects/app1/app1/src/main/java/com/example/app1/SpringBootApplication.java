package javaprojects.app1.app1.src.main.java.com.example.app1;

public @interface SpringBootApplication {

}
