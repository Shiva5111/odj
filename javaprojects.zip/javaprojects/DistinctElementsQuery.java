package javaprojects;

import java.util.*;
// import java.util.Scanner;
// import java.util.Set;

public class DistinctElementsQuery {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int soa=sc.nextInt();
        int soq=sc.nextInt();
        int a1[]=new int[soa];
        int a2[]=new int[soq];
        for(int i=0;i<soa;i++){
            a1[i]=sc.nextInt();
        }
        for(int y=0;y<soq;y++){
            a2[y]=sc.nextInt();
        }
        
        int n=a1.length; 
        for(int z=0;z<soq;z++){
            int start=a2[z];
            Set<Integer> s1=new HashSet<>();
            for(start =a2[z]-1; start<n;start++){
                s1.add(a1[start]);
            }
            System.out.println(s1.size());
        }
    }
}