package javaprojects;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

public class Substring {
    public static void main(String[] args) {
       Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        Queue<Integer> list = new LinkedList<>();
        Stack<Integer> updatedlist=new Stack<>();
        Queue<Integer> finallist=new LinkedList<>();
        for(int i=0;i<n;i++){
            int value=sc.nextInt();
            list.offer(value);
            updatedlist.push(value);
        }
        while(!updatedlist.isEmpty()){
            finallist.offer(updatedlist.pop());
           
        }
        for(int num:finallist){
            System.out.print(num + " ");
        }
    }
}