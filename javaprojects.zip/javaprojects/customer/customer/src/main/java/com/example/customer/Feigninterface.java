package com.example.customer;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient("rapido")
public interface Feigninterface {

    @GetMapping("/rap/riders")
    public List<rider> GetAllRiders();
}
