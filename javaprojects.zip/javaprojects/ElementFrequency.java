package javaprojects;

import java.util.*;

public class ElementFrequency {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int tc=sc.nextInt();
        for(int i=0;i<tc;i++){
            int as=sc.nextInt();
            int a[]=new int[as];
            for(int y=0;y<as;y++){
                a[y]=sc.nextInt();
            }
            Arrays.sort(a);
            for(int z=0;z<a.length;z++){
                int count=0;
                for(int r=0;r<a.length;r++){
                    if(z==a[r]){
                        count++;
                    }
                }
                System.out.print(count + " ");
            }  
            System.out.println();
        }
    }
}
