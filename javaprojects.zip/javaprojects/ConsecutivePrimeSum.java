package javaprojects;

import java.util.*;

public class ConsecutivePrimeSum {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int tc=sc.nextInt();
        int a[]=new int[tc];
        for(int i=0;i<tc;i++){
            a[i]=sc.nextInt();
        }
        List<Integer> c=new ArrayList<>();
        for(int e=0;e<a[i];e++ ){
            c.add(o);
        }
        List<Integer> pa=new ArrayList<>();
        for (int y = 0; y < tc; y++) {
            for(int z=1;z<=a[y];z++){
                int count=0;
                for(int r=2;r<z;r++){
                    if(z%r==0){
                        count++;
                    }
                }
                    pa.add(count);
            }
                for(int b=0;b<a[y];b++){
                    if(pa.get(b)==0){
                        pa.add(a[b]);
                    }
                }
        for (Integer n : pa) {
            System.out.println(n);
        }
    }
}
}
