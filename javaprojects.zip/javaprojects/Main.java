package javaprojects;

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
       Scanner sc=new Scanner(System.in);
        int tc=sc.nextInt();
        for(int i=0;i<tc;i++){
            int n=sc.nextInt();
            int k=sc.nextInt();
            int arr[]=new int[n];
            for(int y=0;y<n;y++){
            arr[y]=sc.nextInt();
            }
            int temp[]=new int[n];
            for (int z = 0; z < n; z++) {
            temp[z] = arr[(z + k) % n];
            }
            for (int elem : temp) {
                System.out.print(elem  + " ");
            }
            System.out.println();
        }
    }
}
