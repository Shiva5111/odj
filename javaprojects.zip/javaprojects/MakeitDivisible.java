
import java.util.*;

public class MakeitDivisible {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int tc=sc.nextInt();
        List<Integer> a=new ArrayList<>();
        for (int i = 0; i < tc; i++) {
            a.add(sc.nextInt());
        }
        List<String>  Stra=new ArrayList<>();
        for (Integer s : a) {
            Stra.add(String.valueOf(s));
        }
        divisible(a, Stra, tc);
    }
    public static void divisible(List<Integer> a,List<String> Stra,int tc){
        for (int i = 0; i < tc; i++) {
            int digits = a.get(i); 
            int lower = (int) Math.pow(10, digits - 1);
            int upper = (int) Math.pow(10, digits);
            List<Integer> r=new ArrayList<>();
            for (int y = lower; y < upper; y++) {
                if(y%3==0 && y%9!=0 && y%2!=0){
                    r.add(y);
                    Collections.sort(r);
                }
            }
            System.out.println(r.get(0));
        }
        
    }
}
 