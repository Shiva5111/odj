package javaprojects;

import java.util.*;

public class FirstNon{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int tc=sc.nextInt();
        for(int i=0;i<tc;i++){
            int as=sc.nextInt();
            int a[]=new int[as];
            for(int y=0;y<as;y++){
                a[y]=sc.nextInt();
            }
            int c[]=new int[a.length];
            for(int z=0;z<a.length;z++){
                int count=0;
                for(int r=0;r<a.length;r++){
                    if(a[z]==a[r]){
                        count++;
                    }
                }
                    c[z]=count;
            }
            boolean found = false;
                for(int b=0;b<a.length;b++){
                    if(c[b]==1){
                        System.out.println(a[b]);
                        found=true;
                        break;
                    }
                }
                if(!found){
                    System.out.println(-1);
                }
        }
    }
}
