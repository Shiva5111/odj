package com.example.demo.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MenuController {

    @GetMapping("/menu")
    public String menu() {
        return "menu";
    }

    @PostMapping("/menu-action")
    public String menuAction(@RequestParam int choice) {

        switch (choice) {
            case 1:
                return "redirect:/employee/create";
            case 2:
                return "redirect:/employee/list";
            case 3:
                return "redirect:/employee/raise";
            case 4:
                return "redirect:/logout";
            default:
                return "redirect:/menu";
        }
    }
}
