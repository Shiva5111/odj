package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;

@Controller
@RequestMapping("/employee")
public class EmployeeController {

    private final EmployeeService service;

    public EmployeeController(EmployeeService service) {
        this.service = service;
    }

    
    @GetMapping("/create")
    public String createPage(Model model) {
        model.addAttribute("employee", new Employee());
        return "create-employee";
    }

    
    @PostMapping("/save")
    public String save(@ModelAttribute Employee employee, Model model) {
        service.save(employee);
        model.addAttribute("msg", "Employee created successfully!");
        model.addAttribute("employee", new Employee());
        return "create-employee";
    }

    
    @GetMapping("/list")
    public String list(Model model) {
        model.addAttribute("employees", service.getAll());
        return "employees";
    }

    
    @GetMapping("/raise")
    public String raisePage() {
        return "raise-salary";
    }

    
    @PostMapping("/raise")
    public String raiseSalary(
            @RequestParam String name,
            @RequestParam int hike,
            Model model) {

        boolean updated = service.raiseSalaryByName(name, hike);

        if(updated) {
            model.addAttribute("msg", "Salary updated successfully!");
        } else {
            model.addAttribute("msg", "Invalid name or hike exceeds limit!");
        }

        return "raise-salary";
    }
}
