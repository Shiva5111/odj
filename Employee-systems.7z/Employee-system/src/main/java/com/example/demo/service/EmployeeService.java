package com.example.demo.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

@Service
public class EmployeeService {

    private final EmployeeRepository repo;

    public EmployeeService(EmployeeRepository repo) {
        this.repo = repo;
    }

   
    public void save(Employee employee) {

        double baseSalary = 0;

        switch(employee.getDesignation()) {
            case "Developer":
            case "Programmer":
                baseSalary = 20000;
                break;
            case "Manager":
                baseSalary = 25000;
                break;
            case "Tester":
                baseSalary = 15000;
                break;
            default:
                baseSalary = 15000; // fallback
        }

        employee.setSalary(baseSalary);
        repo.save(employee);
    }

    public List<Employee> getAll() {
        return repo.findAll();
    }

    
    public boolean raiseSalaryByName(String name, int hike) {

        Employee emp = repo.findByName(name);
        if(emp == null) return false;

        
        int maxHike = 10; 
        switch(emp.getDesignation()) {
            case "Developer":
            case "Programmer":
                maxHike = 10;
                break;
            case "Manager":
                maxHike = 10;
                break;
            case "Tester":
                maxHike = 10;
                break;
        }

        if(hike < 1 || hike > maxHike) {
            return false; 
        }

        double newSalary = emp.getSalary() + (emp.getSalary() * hike / 100.0);
        emp.setSalary(newSalary);
        repo.save(emp);
        return true;
    }
}
